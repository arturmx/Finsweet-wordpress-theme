jQuery(document).ready(function(){
    $('.testimonials__right').slick({
      infinite: false,
      slidesToShow: 1,
      slidesToScroll: 1,
      prevArrow: '.testimonials__arrowleft',
      nextArrow: '.testimonials__arrowright',
      swipe: false,
      fade: true,
    });
  
  });