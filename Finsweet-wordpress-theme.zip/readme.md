Wordpress theme

requies: Advanced Custom Fields


includes:

-6 wordpress pages coded based on Figma project

-blog page with pagination and 4 categories

-custom fields for each site

-js slider

-some hover animations